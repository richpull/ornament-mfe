/// <reference types="react" />
export declare const Context: import("react").Context<string>;
export default Context;
