export * from './compiled-types/apps/remote1/src/exposes/WithProvider';
export { default } from './compiled-types/apps/remote1/src/exposes/WithProvider';