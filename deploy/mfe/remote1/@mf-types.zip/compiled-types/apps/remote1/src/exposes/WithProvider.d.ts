import { FC } from 'react';
import { CheckerProps } from '../../../../packages/components/Checker/index';
export declare const WithProvider: FC<{
    CheckerProps?: CheckerProps;
}>;
export default WithProvider;
